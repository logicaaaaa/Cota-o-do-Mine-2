// Aqui você só precisa ajustar os valores direto no VS Code
let ferroValor = "1 moedas";
let diamanteValor = "10 moedas";

document.getElementById("ferroValor").innerText = ferroValor;
document.getElementById("diamanteValor").innerText = diamanteValor;
